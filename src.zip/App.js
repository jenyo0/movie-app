import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Movie from './Movie.js';

class App extends Component {
//Render : componentWillMount => render => componentDidMount
//Update : componentWillReceiveProps => shouldComponentUpdate    =>    componentWillUpdate => render => componentDidMount
//         새로운 props가 들어왔음       기존props와 새것비교 true리턴    컴포넌트 업데이트
//state가 바뀌면 항상 렌더링함!
state={
  movies:[
    {
      title:"Matrix",
      poster:"http://images.mentalfloss.com/sites/default/files/styles/mf_image_16x9/public/matrix_header.jpg?itok=Ex0PzEVh&resize=1100x619"
    },
    {
      title:  "Full Metal Jacket",
      poster:"https://20ui41tp7v127j03rcnp97oh-wpengine.netdna-ssl.com/wp-content/uploads/2018/01/alberto_fullmetal.jpg"
    },
    {
      title:"Oldboy",
      poster:  "https://lefthandhorror.files.wordpress.com/2013/10/oldboy.jpg"
    },
    {
      title:"Star warz",
      poster:"https://ecurrent.fit.edu/files/2017/11/star-wars-rpg-1401x788-bf5fde32-b497-4b52-8a6f-45aa36325018png.png"
    },
  ]
}

componentDidMount(){
  //받아온 데이터를 처리하는 작업
  setTimeout(()=>{
    this.setState({
      movies:[
        ...this.state.movies,
        {
          title:"Shape of Water",
          poster:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeWZvtC6nQoZlFnY5EhyuhtJHz5rRcTU7Ya4qMcRQ4DfQ0jtAZ"
        }
      ]
    })
  },5000)
}

  render() {
    console.log("did render");
    return (
      <div className="App">
        {this.state.movies.map((movie,index) =>{
          return <Movie title={movie.title} poster={movie.poster} key={index}/>
        })}
      </div>
    );
  }
}

export default App;
